# My-Chrome-extension

Repositório gerado automaticamente contendo um scaffold para testes E2E de uma extensão Chrome (MV3) com Playwright + Docker.

## Como rodar localmente

```bash
# build da imagem
docker compose build

# rodar testes (vai montar volume e executar npm run test:e2e)
docker compose run --rm e2e
```

## Rodando sem container

```bash
npm ci
npm run build
npx playwright install --with-deps chromium
npm run test:e2e
```

## CI
Workflow em `.github/workflows/ci.yml` realiza build, testes e publica artefatos (playwright-report e dist/extension.zip). A criação de release acontece automaticamente se você criar uma tag e dar push (`git tag v1.0 && git push --tags`).
