import fs from 'node:fs';
import path from 'node:path';
import archiver from 'archiver';

const dist = 'dist';
const buildDir = path.join(dist, 'build');

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(buildDir, { recursive: true });

const essentials = [
  'manifest.json',
  'icons',
  'src'
];

for (const item of essentials) {
  const srcPath = path.resolve(item);
  const destPath = path.join(buildDir, path.basename(item));
  if (!fs.existsSync(srcPath)) continue;
  const stats = fs.statSync(srcPath);
  if (stats.isDirectory()) {
    fs.cpSync(srcPath, destPath, { recursive: true });
  } else {
    fs.copyFileSync(srcPath, destPath);
  }
}

// copy buildDir to dist root
fs.cpSync(buildDir, dist, { recursive: true });

const output = fs.createWriteStream(path.join(dist, 'extension.zip'));
const archive = archiver('zip', { zlib: { level: 9 } });
archive.pipe(output);
archive.directory(buildDir + '/', false);
await archive.finalize();
console.log('Build gerado em dist/ e dist/extension.zip');
