// small helper for tests
document.addEventListener('DOMContentLoaded', () => {
  const h = document.getElementById('app');
  if (h) h.textContent = 'My Chrome Extension (ready)';
});
