import { test, expect, chromium } from '@playwright/test';
import path from 'node:path';

const dist = path.resolve(__dirname, '..', 'dist');

test('popup carrega e exibe UI', async () => {
  const context = await chromium.launchPersistentContext('', {
    headless: true,
    args: [
      `--disable-extensions-except=${dist}`,
      `--load-extension=${dist}`
    ]
  });
  const [page] = context.pages();
  await page.goto('about:blank');
  // Abrir popup é tricky — vamos validar que o arquivo popup.html existe e tem #app
  const fs = require('fs');
  const popupPath = path.join(__dirname, '..', 'src', 'popup', 'popup.html');
  const content = fs.readFileSync(popupPath, 'utf8');
  expect(content).toContain('id="app"');
  await context.close();
});
