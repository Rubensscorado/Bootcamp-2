# monorepo-pwa with popup2 embedded

See apps/web/public/index.html for integrated popup.
